"""
SUMMER 현황판 완전 분리버전(data.js)용 봇 수정 패치

핵심 변경:
- 기존 index.html 갱신 방식 대신 data.js 파일의 const INIT=[...] 블록만 갱신합니다.
- UI/CSS/애니메이션/script.js/index.html은 건드리지 않습니다.

적용 방법:
1) 기존 summer_board.py에서 GitHub 경로를 index.html -> data.js 로 변경
2) 기존 update_html_init(...) 대신 아래 update_data_js_init(...) 함수 사용
3) GitHub get/put 함수는 기존 것을 그대로 사용
"""

import re

DATA_PATH = "data.js"


def _num(value, default=0):
    """엑셀 파싱값을 JS 숫자로 안전 변환"""
    if value is None:
        return default
    try:
        if isinstance(value, str):
            value = value.replace(",", "").strip()
            if value == "":
                return default
        return float(value)
    except Exception:
        return default


def normalize_perf_map(parsed):
    """
    parsed 형태를 사번 기준 dict로 통일합니다.

    허용 형태 예시 1:
    {
      "52026082": {"cmip": 752684, "cnt": 4, "canp": 7526246},
      ...
    }

    허용 형태 예시 2:
    [
      {"사번": "52026082", "cmip": 752684, "cnt": 4, "canp": 7526246},
      ...
    ]
    """
    if isinstance(parsed, dict):
        return {str(k).strip(): v for k, v in parsed.items()}

    result = {}
    for row in parsed or []:
        emp = str(row.get("사번") or row.get("emp_no") or row.get("employee_id") or "").strip()
        if not emp:
            continue
        result[emp] = row
    return result


def update_data_js_init(data_js: str, parsed) -> str:
    """
    data.js 안의 FC별 cmip/cnt/canp 숫자만 갱신합니다.
    id/name/사번/지점/순서/UI 코드는 변경하지 않습니다.
    """
    perf = normalize_perf_map(parsed)

    def replace_one(match):
        obj = match.group(0)
        emp_match = re.search(r'사번\s*:\s*"([^"]+)"', obj)
        if not emp_match:
            return obj

        emp = emp_match.group(1).strip()
        if emp not in perf:
            return obj

        row = perf[emp]
        cmip = int(round(_num(row.get("cmip") or row.get("CMIP"), 0)))
        cnt = _num(row.get("cnt") or row.get("CNT") or row.get("건수"), 0)
        canp = int(round(_num(row.get("canp") or row.get("CANP"), 0)))

        obj = re.sub(r'cmip\s*:\s*[-]?[0-9]+(?:\.[0-9]+)?', f'cmip:{cmip}', obj)
        obj = re.sub(r'cnt\s*:\s*[-]?[0-9]+(?:\.[0-9]+)?', f'cnt:{cnt}', obj)
        obj = re.sub(r'canp\s*:\s*[-]?[0-9]+(?:\.[0-9]+)?', f'canp:{canp}', obj)
        return obj

    # INIT 배열 내부의 객체 단위로만 치환
    updated = re.sub(r'\{id\s*:[^{}]*?사번\s*:\s*"[^"]+"[^{}]*?\}', replace_one, data_js)
    return updated


# 기존 update_summer_board 내부 변경 예시:
#
# old_html, sha = get_github_file("index.html")
# new_html = update_html_init(old_html, parsed_result)
# update_github_file("index.html", new_html, sha, "update summer board")
#
# ↓ 아래처럼 변경
#
# old_data_js, sha = get_github_file(DATA_PATH)
# new_data_js = update_data_js_init(old_data_js, parsed_result)
# update_github_file(DATA_PATH, new_data_js, sha, "update summer board data")
