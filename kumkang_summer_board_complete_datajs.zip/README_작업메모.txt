금강 SUMMER 현황판 분리 버전

변경 목적:
- UI/기능 변경 없이 파일만 분리
- index.html 경량화
- CSS/JS/동영상 assets 분리

구조:
index.html
style.css
script.js
assets/video/vid1.mp4
assets/video/vid2.mp4
assets/video/vid3.mp4
assets/img/logo.png

주의:
- 기존 기능/UI를 바꾸지 않기 위해 코드 로직은 그대로 유지했습니다.
- GitHub에는 폴더 구조 그대로 업로드해야 합니다.
- 업적봇이 index.html 안의 데이터만 수정하도록 되어 있다면, 앞으로는 script.js 쪽 데이터 수정 구조와 맞춰야 할 수 있습니다.
